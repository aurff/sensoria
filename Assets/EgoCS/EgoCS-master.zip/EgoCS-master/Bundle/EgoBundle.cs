﻿public abstract class EgoBundle{ }
